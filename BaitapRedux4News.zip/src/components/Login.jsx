import React, {Component} from 'react';
import './login.css';
import { 
    atx_login,
    atx_getData,
} from '../actions/actions'
import { connect } from "react-redux";
import $ from 'jquery'; 

class Login extends Component {
    constructor(props){
        super(props);
        this.state = {
            username: "",
            password: "",
        }   
    }

    onChangeUsername = e => {
        this.setState({
          username: e.target.value
        })
    }

    onChangePassword = e => {
        this.setState({
          password: e.target.value
        })
    }

    submit = (e) => {
        e.preventDefault();
        if (this.state.username === "" || this.state.password === "") alert("INPUT ERROR");
        else{
            this.props.atx_login(this.state.username, this.state.password,this.props.history2 );
            // if ( localStorage.getItem('username') !== null && localStorage.getItem('password') !== null) {
            //     this.props.atx_getData();
            //     $('.navbar-inverse .navbar-nav>li>a').removeClass("focus");
            //     $('.navbar-inverse .navbar-nav>li:nth-child(' + 1 + ') a').addClass("focus");
            //     this.props.history2.push("/");
            // } 

            
        }
    }

    render(){
        return (
            <div>
                <form onSubmit={this.submit}>
                    <legend>Login now</legend>
                    <div className="form-group">
                        <label htmlFor="">Username</label>
                        <input 
                            type="text" 
                            className="form-control" 
                            id="username-login" 
                            placeholder="Input field" 
                            value={this.state.username}
                            onChange={this.onChangeUsername}
                        /> 
                        <label htmlFor="">Password</label>
                        <input 
                            className="form-control" 
                            id="password-login" 
                            placeholder="Input field" 
                            type="password"
                            value={this.state.password}
                            onChange={this.onChangePassword}
                        /> 
                    </div>
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
            </div>
            
        );
    }
}

function mapStateToProps(state) {
    return {
        ...state
    };
}
function mapDispatchToProps(dispatch) {
    return {
        atx_login: (username,password,aaa) => dispatch(atx_login(username,password,aaa)),
        atx_getData: () => dispatch(atx_getData()),
    }
}
  
export default connect(mapStateToProps,mapDispatchToProps)(Login);